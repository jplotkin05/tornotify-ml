"""Ski-mountain routing prototype.

A resort is a directed, weighted graph. Runs go downhill, lifts go up.
This loads the sample graph and runs Dijkstra under a few different cost
functions and constraints — proving the model before any AWS is involved.

Run:  python3 route.py
"""
import heapq
import json
from pathlib import Path

DATA = Path(__file__).resolve().parents[2] / "data" / "sample-resort.json"

# difficulty ordinal: 0 = lift (n/a), 1 green, 2 blue, 3 black, 4 double black
DIFFICULTY_NAME = {0: "lift", 1: "green", 2: "blue", 3: "black", 4: "double-black"}


def load_graph(path=DATA):
    """Return (nodes_by_id, edges). edges is a flat list of dicts."""
    raw = json.loads(Path(path).read_text())
    nodes = {n["id"]: n for n in raw["nodes"]}
    return nodes, raw["edges"]


def build_adjacency(edges, *, cost, max_difficulty=None, avoid=None):
    """adj[u] = list of (v, edge_cost, edge). Filters apply before search.

    cost: fn(edge) -> number   (the pluggable weight function)
    max_difficulty: drop run edges harder than this
    avoid: set of edge names to exclude
    """
    avoid = avoid or set()
    adj = {}
    for e in edges:
        if e["name"] in avoid:
            continue
        if max_difficulty is not None and e.get("difficulty", 0) > max_difficulty:
            continue
        adj.setdefault(e["from"], []).append((e["to"], cost(e), e))
    return adj


def dijkstra(adj, start, goal):
    """Classic shortest path. Returns (total_cost, [edges]) or (inf, [])."""
    counter = 0  # tiebreaker so heapq never compares paths when costs are equal
    pq = [(0.0, counter, start, [])]
    seen = set()
    while pq:
        c, _, node, path = heapq.heappop(pq)
        if node == goal:
            return c, path
        if node in seen:
            continue
        seen.add(node)
        for v, w, edge in adj.get(node, []):
            if v not in seen:
                counter += 1
                heapq.heappush(pq, (c + w, counter, v, path + [edge]))
    return float("inf"), []


# --- pluggable cost functions ---------------------------------------------
def cost_time(e):
    return e["est_min"]


def cost_easy(e):
    # gentlest descent: penalize difficulty heavily on top of time
    return e["est_min"] + 5 * max(0, e.get("difficulty", 0) - 1)


def describe(nodes, total, path, unit="min"):
    if not path:
        return "  no route found (constraints too tight?)"
    lines = [f"  total: {total:g} {unit}"]
    for e in path:
        kind = e["type"].upper()
        diff = DIFFICULTY_NAME.get(e.get("difficulty", 0), "?")
        frm, to = nodes[e["from"]]["name"], nodes[e["to"]]["name"]
        lines.append(f"    {kind:<4} {e['name']:<14} {frm} -> {to}  ({diff}, {e['est_min']}m)")
    return "\n".join(lines)


def main():
    nodes, edges = load_graph()
    print(f"Loaded '{json.loads(DATA.read_text())['resort']}': "
          f"{len(nodes)} nodes, {len(edges)} edges\n")

    print("1) Fastest route base -> summit (by time):")
    adj = build_adjacency(edges, cost=cost_time)
    print(describe(nodes, *dijkstra(adj, "base", "summit")), "\n")

    print("2) Easiest way down summit -> base (avoid hard runs):")
    adj = build_adjacency(edges, cost=cost_easy)
    print(describe(nodes, *dijkstra(adj, "summit", "base")), "\n")

    print("3) Summit -> base for a beginner (max difficulty = green):")
    adj = build_adjacency(edges, cost=cost_time, max_difficulty=1)
    print(describe(nodes, *dijkstra(adj, "summit", "base")), "\n")

    print("4) Summit -> base avoiding 'Green Highway':")
    adj = build_adjacency(edges, cost=cost_time, avoid={"Green Highway"})
    print(describe(nodes, *dijkstra(adj, "summit", "base")))


if __name__ == "__main__":
    main()
