"""Render a resort graph JSON as a Graphviz diagram.

Reads a resort file (same schema as data/sample-resort.json) and emits a DOT
file plus a PNG so you can *see* how the mountain mapped onto the graph model:
nodes = stations/junctions, edges = runs (downhill, colored by difficulty) and
lifts (uphill, dashed red).

Usage:
    python3 scripts/render_graph.py data/blue-sky-basin.json
    python3 scripts/render_graph.py data/blue-sky-basin.json -o build/blue-sky

Needs the Graphviz `dot` binary on PATH (it is, via Homebrew).
"""
import argparse
import json
import shutil
import subprocess
from pathlib import Path

# difficulty ordinal -> (label, edge color, pen width)
DIFF_STYLE = {
    0: ("lift", "#d62728", 2.0),   # lift (only used if a lift sneaks in here)
    1: ("road", "#2c7fb8", 1.4),   # road / catwalk (Blue Sky has no greens)
    2: ("blue", "#1f78b4", 1.8),   # more difficult
    3: ("black", "#111111", 2.2),  # most difficult
    4: ("dbl-black", "#111111", 3.0),
}

# node type -> graphviz shape/fill
NODE_STYLE = {
    "summit":   ("octagon",     "#ffe6e6"),
    "lodge":    ("house",       "#fff2cc"),
    "base":     ("box",         "#e6f2ff"),
    "junction": ("ellipse",     "#f2f2f2"),
}


def esc(s):
    return str(s).replace('"', '\\"')


def build_dot(data):
    resort = data.get("resort", "Resort")
    nodes = data["nodes"]
    edges = data["edges"]

    lines = [
        "digraph resort {",
        '  rankdir=TB;',
        '  bgcolor="white";',
        '  labelloc="t";',
        f'  label=<<b>{esc(resort)}</b><br/><font point-size="10">'
        f'{len(nodes)} nodes &#183; {len(edges)} edges &#183; runs go down, lifts go up</font>>;',
        '  fontname="Helvetica"; fontsize=18;',
        '  node [fontname="Helvetica", fontsize=11, style="filled", penwidth=1.2];',
        '  edge [fontname="Helvetica", fontsize=9];',
        "",
    ]

    # rank nodes top-to-bottom by elevation so the picture reads like a mountain
    ranked = sorted(nodes, key=lambda n: -n.get("elevation", 0))
    for n in ranked:
        shape, fill = NODE_STYLE.get(n.get("type", "junction"), ("ellipse", "#f2f2f2"))
        elev = n.get("elevation")
        sub = f'<br/><font point-size="8">{elev} m</font>' if elev else ""
        lines.append(
            f'  "{n["id"]}" [shape={shape}, fillcolor="{fill}", '
            f'label=<{esc(n["name"])}{sub}>];'
        )
    lines.append("")

    for e in edges:
        is_lift = e.get("type") == "lift"
        if is_lift:
            color, width, style, arrow = "#d62728", 2.0, "dashed", "normal"
            tag = "lift"
        else:
            label, color, width = DIFF_STYLE.get(e.get("difficulty", 2), ("?", "#888888", 1.5))
            style, arrow, tag = "solid", "normal", label
        mins = e.get("est_min")
        lbl = f'{esc(e["name"])}' + (f'\\n{mins}m' if mins is not None else "")
        lines.append(
            f'  "{e["from"]}" -> "{e["to"]}" '
            f'[label="{lbl}", color="{color}", fontcolor="{color}", '
            f'penwidth={width}, style={style}, arrowhead={arrow}];'
        )

    # legend
    lines += [
        "",
        "  subgraph cluster_legend {",
        '    label="legend"; fontsize=10; color="#cccccc"; style="dashed";',
        '    node [shape=plaintext, style="", fillcolor="white"];',
        '    legend [label=<',
        '      <table border="0" cellborder="0" cellspacing="2">',
        '        <tr><td align="left"><font color="#d62728">- - &#8593; lift</font></td></tr>',
        '        <tr><td align="left"><font color="#2c7fb8">&#8594; road / catwalk</font></td></tr>',
        '        <tr><td align="left"><font color="#1f78b4">&#8594; blue run</font></td></tr>',
        '        <tr><td align="left"><font color="#111111">&#8594; black run</font></td></tr>',
        "      </table>>];",
        "  }",
        "}",
    ]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Render a resort graph as a Graphviz diagram.")
    ap.add_argument("resort_json", help="path to resort JSON (data/*.json)")
    ap.add_argument("-o", "--out", help="output basename (default: build/<resort-file-stem>)")
    ap.add_argument("-f", "--format", default="png", help="output format for dot (png, svg, pdf)")
    args = ap.parse_args()

    src = Path(args.resort_json)
    data = json.loads(src.read_text())

    out = Path(args.out) if args.out else Path("build") / src.stem
    out.parent.mkdir(parents=True, exist_ok=True)
    dot_path = out.with_suffix(".dot")
    img_path = out.with_suffix("." + args.format)

    dot_path.write_text(build_dot(data))
    print(f"wrote {dot_path}")

    if not shutil.which("dot"):
        print("graphviz 'dot' not found on PATH; wrote DOT only.")
        return
    subprocess.run(["dot", f"-T{args.format}", str(dot_path), "-o", str(img_path)], check=True)
    print(f"wrote {img_path}")


if __name__ == "__main__":
    main()
