# Domain model — the ski mountain as a graph

## Node types
| type      | meaning                          | key attrs                          |
|-----------|----------------------------------|------------------------------------|
| `summit`  | top of a peak                    | elevation                          |
| `junction`| where trails split/merge         | elevation                          |
| `lift_base` / `lift_top` | endpoints of a lift   | elevation                          |
| `lodge`   | food / facilities / start point  | elevation, services                |
| `base`    | parking / resort entry           | elevation                          |

Every node has: `id`, `name`, `type`, `elevation` (m), `lat`, `lon`.

## Edge types
| type    | direction | weights                                        |
|---------|-----------|------------------------------------------------|
| `run`   | downhill  | `length_m`, `vertical_m`, `difficulty`, `est_min` |
| `lift`  | uphill    | `est_min` (ride time), `capacity`, `status`    |

`difficulty`: `green` < `blue` < `black` < `double_black` (use an ordinal scale 1–4).

## Why directed
You can't ski up a run, and a chairlift only goes one way. Directed edges make the
routing physically correct for free — a path is a real sequence a skier can follow.

## Weight functions (pluggable cost)
The same topology serves many queries by changing the edge cost:
- **time**: `est_min` on every edge → fastest route.
- **easy**: `est_min + difficulty_penalty` → gentlest descent.
- **vertical**: `-vertical_m` on runs → maximize ski time (most descent).

## Constraints (filters, not costs)
- max difficulty allowed (drop edges above threshold before search)
- avoid a specific lift/run (drop those edges)
- lift status == open (live data layer)

## Live data layer (later)
Lift open/closed, wait times, grooming, snow conditions, closures. These mutate edge
weights/availability at query time without changing topology.
