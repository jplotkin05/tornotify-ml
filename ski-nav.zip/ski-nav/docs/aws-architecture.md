# AWS architecture — and how each service earns its place

You said you have lots of AWS available and want to learn — this project is a great
vehicle because almost every layer maps to a service. Here's a staged path so you
learn one thing at a time instead of standing up everything at once.

## Does AWS help? Yes — concretely:
1. **Graph storage** is a first-class AWS thing (Neptune is a managed graph DB).
2. **Routing on demand** is a textbook serverless API (API Gateway + Lambda).
3. **Live conditions** (lift status, weather) fit event-driven AWS patterns.
4. **Maps/visualization** has a managed service (Amazon Location Service).

## Stage 0 — Local (no AWS, start here)
Pure Python graph + Dijkstra in `src/graph/`. Prove the model and routing logic
before paying for or wiring up any cloud. Already scaffolded.

## Stage 1 — Serverless API (cheapest real cloud, best learning ROI)
```
client → API Gateway → Lambda (routing) → DynamoDB (graph as adjacency lists)
```
- **DynamoDB**: store nodes and edges. Simple schema: PK=`NODE#<id>` for node attrs,
  PK=`NODE#<id>` SK=`EDGE#<toId>` for adjacency. Load whole resort (small) into the
  Lambda and run Dijkstra in memory — a resort is only hundreds of nodes.
- **Lambda**: stateless routing function. Cold-loads the graph (or caches it).
- **API Gateway**: `GET /route?from=X&to=Y&mode=easy`.
- Teaches: IAM, Lambda, DynamoDB, API Gateway, CloudWatch logs. ~$0 at this scale.

## Stage 2 — Managed graph DB (when you want "real" graph queries)
Swap DynamoDB for **Amazon Neptune** if you want Gremlin/openCypher traversals,
or many resorts / huge graphs. Likely overkill for a single resort but excellent
for *learning graph databases*. Neptune is not serverless-cheap (runs an instance),
so treat it as a deliberate learning exercise, not the default.

## Stage 3 — Live conditions (event-driven)
```
lift/weather feed → EventBridge → Lambda → update edge status in DynamoDB
```
- **EventBridge** scheduled rules to poll feeds; **Lambda** to normalize and write.
- Optionally **IoT Core** if you ever ingest real lift sensor telemetry.

## Stage 4 — Maps & geo
- **Amazon Location Service**: render the resort, place nodes by lat/lon, draw routes.
- Or export GeoJSON and render client-side (Mapbox/Leaflet) to save cost.

## Stage 5 — Frontend
- **S3 + CloudFront** for a static web/mobile-web app. Cheap, standard, learnable.

## Data sourcing
- **OpenStreetMap** has `piste:*` tags (ski runs) and `aerialway=*` (lifts). You can
  extract a resort's runs/lifts from OSM and build the graph automatically.
  `scripts/` is where an OSM → graph importer would live.

## Cost-safety note
Stages 1, 3, 5 are effectively free at hobby scale (serverless, pay-per-request).
Neptune (Stage 2) and always-on resources cost real money — spin up, learn, tear down.

## Recommended order
0 → 1 → 3 → 5, then 2/4 as learning side-quests. Get a working API over the sample
graph first; everything else hangs off that.
