# ski-nav

A ski-mountain navigation service. Model each resort as a **directed, weighted graph**
and run shortest-path / constrained routing over it ("get me from the lodge to the
black-diamond bowl avoiding lift X", "easiest way down from the summit", etc.).

## Why a graph
- **Nodes** = lift stations, trail junctions, lodges, parking, summit/base points.
- **Edges** = trails (runs) and lift segments. Each edge is *directed* — you ski runs
  downhill only; lifts go up only.
- **Edge weights** = time, vertical drop, distance, difficulty, or "skier energy".
  Swap the weight function and the same graph answers different questions.

## Routing questions this enables
- Easiest / fastest route between two points.
- "Avoid this difficulty" (filter edges by `difficulty <= intermediate`).
- "Stay on this side of the mountain" (subgraph constraint).
- Multi-criteria: minimize time but cap total black-diamond pitch.

## Layout
- `docs/` — concept, domain model, AWS architecture, roadmap.
- `data/` — sample resort graph (`sample-resort.json`) + real data later.
- `src/graph/` — graph model + routing prototype (pure Python, no cloud needed).
- `src/api/` — service layer (REST/GraphQL) added later.
- `infra/` — IaC (CDK/Terraform) for the AWS deployment.
- `scripts/` — data ingestion / OSM import helpers.

## Quick start (local prototype)
```bash
cd src/graph
python3 route.py
```

See `docs/aws-architecture.md` for how this maps onto AWS as you grow it.
